<?php
declare(strict_types=1);
header('Content-Type: application/xml; charset=utf-8');

$db = Database::getConnection();
$baseUrl = 'https://yourdomain.com';

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

// Homepage
echo "<url>
    <loc>{$baseUrl}/</loc>
    <lastmod>" . date('Y-m-d') . "</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
</url>";

// Static pages
$pages = ['about', 'services', 'contact', 'blogs'];
foreach ($pages as $page) {
    echo "<url>
        <loc>{$baseUrl}/{$page}</loc>
        <lastmod>" . date('Y-m-d') . "</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>";
}

// Dynamic blog posts
$stmt = $db->query(
    "SELECT slug, published_at FROM blogs WHERE status = 'published' ORDER BY published_at DESC"
);
while ($blog = $stmt->fetch()) {
    $lastmod = date('Y-m-d', strtotime($blog['published_at']));
    echo "<url>
        <loc>{$baseUrl}/blog/{$blog['slug']}</loc>
        <lastmod>{$lastmod}</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.6</priority>
    </url>";
}

echo '</urlset>';

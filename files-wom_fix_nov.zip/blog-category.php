<?php
require_once 'config/config.php';

// Get category from URL
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

if(empty($category)) {
    header('Location: /blogs');
    exit();
}

// Pagination
$page_num = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 9;
$offset = ($page_num - 1) * $per_page;

// Fetch blogs by category
try {
    // Get total blogs in this category
    $total_stmt = $db->prepare("SELECT COUNT(*) as total FROM blogs WHERE category = ? AND status = 'published'");
    $total_stmt->execute([$category]);
    $total = $total_stmt->fetch()['total'];
    $total_pages = ceil($total / $per_page);
    
    // Fetch blogs - FIX: Use bindValue for integers
    $stmt = $db->prepare("SELECT * FROM blogs WHERE category = ? AND status = 'published' ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $category, PDO::PARAM_STR);
    $stmt->bindValue(2, $per_page, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $blogs = $stmt->fetchAll();
    
} catch(PDOException $e) {
    error_log("Category Error: " . $e->getMessage());
    $blogs = [];
    $total = 0;
    $total_pages = 0;
}

// Get all categories with count
try {
    $categories_stmt = $db->query("SELECT category, COUNT(*) as count FROM blogs WHERE status = 'published' GROUP BY category ORDER BY category ASC");
    $categories = $categories_stmt->fetchAll();
} catch(Exception $e) {
    $categories = [];
}

// SEO Data
$customSeoData = [
    'title' => ucfirst($category) . ' Blog Posts | ' . SITE_NAME,
    'description' => 'Explore our ' . $category . ' articles, tips, and insights. Learn the latest trends and strategies in ' . $category . ' from industry experts.',
    'keywords' => $category . ', ' . $category . ' tips, ' . $category . ' strategies, digital marketing, ' . SITE_NAME,
    'url' => SITE_URL . '/blog-category?category=' . urlencode($category),
    'type' => 'blog',
    'image' => SITE_URL . '/assets/images/category-og.jpg'
];
?>
<?php require_once 'includes/header.php'; ?>

<style>
.page-hero {
    background: linear-gradient(135deg, #1a1a1a 0%, #000000 100%);
    color: white;
    padding: 100px 0 60px;
    text-align: center;
}

.page-hero h1 {
    font-size: 3rem;
    margin-bottom: 15px;
    font-weight: 700;
}

.page-hero p {
    font-size: 1.2rem;
    opacity: 0.9;
}

.page-hero .category-icon {
    font-size: 4rem;
    margin-bottom: 20px;
    opacity: 0.8;
}

.blog-section {
    padding: 80px 0;
}

.blog-layout {
    display: grid;
    grid-template-columns: 1fr 350px;
    gap: 50px;
}

.blog-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
}

.blog-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s;
    text-decoration: none;
    display: block;
}

.blog-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.blog-card-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.blog-card-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}

.blog-card:hover .blog-card-image img {
    transform: scale(1.1);
}

.blog-card-content {
    padding: 25px;
}

.blog-category {
    display: inline-block;
    padding: 5px 12px;
    background: #000;
    color: white;
    border-radius: 3px;
    font-size: 0.8rem;
    font-weight: 600;
    margin-bottom: 15px;
    text-transform: uppercase;
}

.blog-card h3 {
    font-size: 1.3rem;
    margin-bottom: 10px;
    color: #000;
    line-height: 1.4;
}

.blog-excerpt {
    color: #666;
    line-height: 1.6;
    margin-bottom: 15px;
}

.blog-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.85rem;
    color: #999;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
}

.blog-meta span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.sidebar {
    position: sticky;
    top: 100px;
}

.sidebar-widget {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.sidebar-widget h3 {
    font-size: 1.3rem;
    margin-bottom: 20px;
    color: #000;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.category-list {
    list-style: none;
}

.category-list li {
    margin-bottom: 10px;
}

.category-list a {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background: #f8f8f8;
    border-radius: 5px;
    text-decoration: none;
    color: #333;
    transition: all 0.3s;
    font-weight: 500;
}

.category-list a:hover,
.category-list a.active {
    background: #000;
    color: white;
    padding-left: 20px;
}

.category-count {
    background: rgba(0,0,0,0.1);
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 600;
}

.category-list a.active .category-count {
    background: rgba(255,255,255,0.2);
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 50px;
}

.pagination a,
.pagination span {
    padding: 10px 15px;
    background: white;
    border: 2px solid #e0e0e0;
    border-radius: 5px;
    text-decoration: none;
    color: #333;
    font-weight: 600;
    transition: all 0.3s;
    min-width: 45px;
    text-align: center;
}

.pagination a:hover,
.pagination span.active {
    background: #000;
    color: white;
    border-color: #000;
}

.empty-state {
    text-align: center;
    padding: 80px 20px;
    background: white;
    border-radius: 10px;
}

.empty-state i {
    font-size: 4rem;
    color: #ccc;
    margin-bottom: 20px;
}

.empty-state h2 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #333;
}

.empty-state p {
    color: #666;
    margin-bottom: 20px;
}

.btn-primary {
    display: inline-block;
    padding: 12px 25px;
    background: #000;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-primary:hover {
    background: #333;
    transform: translateY(-2px);
}

@media (max-width: 968px) {
    .blog-layout {
        grid-template-columns: 1fr;
    }
    
    .sidebar {
        position: static;
    }
    
    .page-hero h1 {
        font-size: 2rem;
    }
    
    .blog-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<section class="page-hero">
    <div class="container">
        <div class="category-icon">
            <i class="fas fa-folder-open"></i>
        </div>
        <h1><?php echo ucfirst(htmlspecialchars($category)); ?> Articles</h1>
        <p>Explore <strong><?php echo $total; ?></strong> <?php echo $total == 1 ? 'article' : 'articles'; ?> in this category</p>
    </div>
</section>

<section class="blog-section">
    <div class="container">
        <div class="blog-layout">
            <!-- Main Content -->
            <div class="main-content">
                <?php if(!empty($blogs)): ?>
                    <div class="blog-grid">
                        <?php foreach($blogs as $blog): ?>
                        <a href="/blogs/<?php echo htmlspecialchars($blog['slug']); ?>" class="blog-card">
                            <div class="blog-card-image">
                                <img src="<?php echo htmlspecialchars($blog['featured_image']); ?>" 
                                     alt="<?php echo htmlspecialchars($blog['title']); ?>"
                                     onerror="this.src='https://via.placeholder.com/400x200/000/FFF?text=<?php echo urlencode($blog['title']); ?>'">
                            </div>
                            <div class="blog-card-content">
                                <span class="blog-category"><?php echo htmlspecialchars($blog['category']); ?></span>
                                <h3><?php echo htmlspecialchars($blog['title']); ?></h3>
                                <p class="blog-excerpt">
                                    <?php echo htmlspecialchars(substr(strip_tags($blog['content']), 0, 120)) . '...'; ?>
                                </p>
                                <div class="blog-meta">
                                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($blog['author']); ?></span>
                                    <span><i class="fas fa-eye"></i> <?php echo number_format($blog['views']); ?> views</span>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if($page_num > 1): ?>
                        <a href="?category=<?php echo urlencode($category); ?>&page=<?php echo $page_num - 1; ?>">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                        <?php endif; ?>
                        
                        <?php for($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if($i == $page_num): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?category=<?php echo urlencode($category); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if($page_num < $total_pages): ?>
                        <a href="?category=<?php echo urlencode($category); ?>&page=<?php echo $page_num + 1; ?>">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-folder-open"></i>
                        <h2>No Articles Found</h2>
                        <p>There are no published articles in "<strong><?php echo htmlspecialchars($category); ?></strong>" category yet.</p>
                        <a href="/blogs" class="btn-primary">
                            <i class="fas fa-arrow-left"></i> View All Blogs
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Sidebar -->
            <aside class="sidebar">
                <!-- Categories Widget -->
                <div class="sidebar-widget">
                    <h3><i class="fas fa-folder"></i> All Categories</h3>
                    <ul class="category-list">
                        <?php if(!empty($categories)): ?>
                            <?php foreach($categories as $cat): ?>
                            <li>
                                <a href="/blog-category?category=<?php echo urlencode($cat['category']); ?>" 
                                   class="<?php echo $cat['category'] == $category ? 'active' : ''; ?>">
                                    <span><?php echo htmlspecialchars($cat['category']); ?></span>
                                    <span class="category-count"><?php echo $cat['count']; ?></span>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li style="text-align:center; color:#999; padding:20px;">No categories found</li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- All Blogs Button -->
                <div class="sidebar-widget">
                    <a href="/blogs" class="btn-primary" style="display:block; text-align:center; width:100%;">
                        <i class="fas fa-th-large"></i> View All Blogs
                    </a>
                </div>
            </aside>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>

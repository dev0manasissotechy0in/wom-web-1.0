<?php
declare(strict_types=1);

require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Newsletter {
    private PDO $db;
    
    public function __construct() {
        $this->db = Database::getConnection();
    }
    
    public function subscribe(string $email): bool {
        $stmt = $this->db->prepare(
            "INSERT INTO newsletter_subscribers (email, ip_address) 
             VALUES (:email, :ip) 
             ON DUPLICATE KEY UPDATE status = 'active'"
        );
        
        return $stmt->execute([
            'email' => filter_var($email, FILTER_VALIDATE_EMAIL),
            'ip' => $_SERVER['REMOTE_ADDR']
        ]);
    }
    
    public function sendBulkEmail(int $blogId, string $subject, string $body): array {
        $stmt = $this->db->prepare(
            "SELECT email FROM newsletter_subscribers WHERE status = 'active'"
        );
        $stmt->execute();
        $subscribers = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $results = ['sent' => 0, 'failed' => 0];
        
        foreach ($subscribers as $email) {
            if ($this->sendEmail($email, $subject, $body)) {
                $results['sent']++;
            } else {
                $results['failed']++;
            }
        }
        
        return $results;
    }
    
    private function sendEmail(string $to, string $subject, string $body): bool {
        $mail = new PHPMailer(true);
        
        try {
            // ZOHO SMTP Configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.zoho.com';
            $mail->SMTPAuth = true;
            $mail->Username = '[email protected]';
            $mail->Password = 'your-app-password';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;
            
            $mail->setFrom('[email protected]', 'Your Company');
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            
            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Email Error: " . $mail->ErrorInfo);
            return false;
        }
    }
}

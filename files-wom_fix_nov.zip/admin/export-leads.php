<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    die('Unauthorized');
}

$db = new PDO(
    'mysql:host=sg2plzcpnl492040.prod.sin2.secureserver.net;dbname=wom_self;charset=utf8mb4',
    'wom_self_u',
    't??B)M{bfb}H'
);

$resource_id = (int)($_GET['resource_id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM resource_downloads WHERE resource_id = ? ORDER BY downloaded_at DESC");
$stmt->execute([$resource_id]);
$leads = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="leads_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Name', 'Email', 'Phone', 'Company', 'IP Address', 'Download Date']);

foreach ($leads as $lead) {
    fputcsv($output, [
        $lead['name'],
        $lead['email'],
        $lead['phone'],
        $lead['company'],
        $lead['ip_address'],
        date('Y-m-d H:i:s', strtotime($lead['downloaded_at']))
    ]);
}

fclose($output);
?>

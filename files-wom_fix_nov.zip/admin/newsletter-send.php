<?php
declare(strict_types=1);
require_once '../config/database.php';
require_once '../classes/Newsletter.php';

// Authentication check here

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $blogId = (int)$_POST['blog_id'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    
    $newsletter = new Newsletter();
    $results = $newsletter->sendBulkEmail($blogId, $subject, $body);
    
    echo json_encode($results);
    exit;
}

// Get published blogs for selection
$db = Database::getConnection();
$blogs = $db->query(
    "SELECT id, title, published_at FROM blogs WHERE status = 'published' ORDER BY published_at DESC"
)->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Send Newsletter</title>
</head>
<body>
    <h1>Send Blog to Newsletter Subscribers</h1>
    
    <form id="newsletterForm">
        <select name="blog_id" required>
            <option value="">Select Blog Post</option>
            <?php foreach ($blogs as $blog): ?>
                <option value="<?= $blog['id'] ?>">
                    <?= htmlspecialchars($blog['title']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <input type="text" name="subject" placeholder="Email Subject" required>
        <textarea name="body" placeholder="Email Body (HTML supported)" required></textarea>
        
        <button type="submit" id="sendBtn">Send to All Subscribers</button>
    </form>
    
    <div id="results"></div>
    
    <script>
    document.getElementById('newsletterForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('sendBtn');
        btn.disabled = true;
        btn.textContent = 'Sending...';
        
        const formData = new FormData(e.target);
        const response = await fetch('/admin/newsletter-send.php', {
            method: 'POST',
            body: formData
        });
        
        const results = await response.json();
        document.getElementById('results').innerHTML = 
            `<p>Sent: ${results.sent}, Failed: ${results.failed}</p>`;
        
        btn.disabled = false;
        btn.textContent = 'Send to All Subscribers';
    });
    </script>
</body>
</html>

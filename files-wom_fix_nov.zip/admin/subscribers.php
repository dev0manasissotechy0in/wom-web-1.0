<?php
require_once '../config/config.php';

if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Handle delete
if(isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->prepare("DELETE FROM newsletter_subscribers WHERE id = ?")->execute([$id]);
    header('Location: subscribers.php?msg=deleted');
    exit();
}

$subscribers = $db->query("SELECT * FROM newsletter_subscribers ORDER BY subscribed_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Newsletter Subscribers - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="content">
            <div class="page-header">
                <h1>Newsletter Subscribers</h1>
                <a href="newsletter.php" class="btn-primary"><i class="fas fa-paper-plane"></i> Send Newsletter</a>
            </div>
            
            <?php if(isset($_GET['msg'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Subscriber deleted successfully!
                </div>
            <?php endif; ?>
            
            <div class="content-card">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Subscribed Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($subscribers as $subscriber): ?>
                            <tr>
                                <td><?php echo $subscriber['id']; ?></td>
                                <td><?php echo htmlspecialchars($subscriber['email']); ?></td>
                                <td><?php echo htmlspecialchars($subscriber['name'] ?: 'N/A'); ?></td>
                                <td>
                                    <span class="badge <?php echo $subscriber['status'] == 'subscribed' ? 'badge-success' : 'badge-warning'; ?>">
                                        <?php echo $subscriber['status']; ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($subscriber['subscribed_at'])); ?></td>
                                <td>
                                    <a href="?delete=<?php echo $subscriber['id']; ?>" class="btn-icon btn-danger" onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

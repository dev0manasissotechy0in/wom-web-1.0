<?php
require_once '../config/config.php';
require_once '../config/smtp.php';

if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = sanitize($_POST['subject']);
    $body = $_POST['body'];
    
    // Get all subscribed users
    $stmt = $db->query("SELECT email, name FROM newsletter_subscribers WHERE status = 'subscribed'");
    $subscribers = $stmt->fetchAll();
    
    if(sendNewsletterBulk($subscribers, $subject, $body)) {
        $message = "Newsletter sent successfully to " . count($subscribers) . " subscribers!";
    } else {
        $error = "Failed to send newsletter.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Newsletter - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="content">
            <div class="page-header">
                <h1>Send Newsletter</h1>
            </div>
            
            <?php if(!empty($message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if(!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="content-card">
                <form method="POST" class="form">
                    <div class="form-group">
                        <label>Subject <span class="required">*</span></label>
                        <input type="text" name="subject" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Message (HTML) <span class="required">*</span></label>
                        <textarea name="body" class="form-control" rows="15" required></textarea>
                        <small>You can use HTML tags for formatting</small>
                    </div>
                    
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-paper-plane"></i> Send Newsletter
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

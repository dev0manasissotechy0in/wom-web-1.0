<?php
require_once '../config/config.php';

if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

$message = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'site_name', 'contact_email', 'contact_phone', 'address',
        'facebook_url', 'instagram_url', 'linkedin_url', 'twitter_url',
        'meta_title', 'meta_description', 'meta_keywords',
        'google_analytics_id', 'facebook_pixel_id', 'theme_color'
    ];
    
    $updates = [];
    $values = [];
    
    foreach($fields as $field) {
        $updates[] = "$field = ?";
        $values[] = sanitize($_POST[$field] ?? '');
    }
    
    $sql = "UPDATE site_settings SET " . implode(', ', $updates) . " WHERE id = 1";
    $stmt = $db->prepare($sql);
    $stmt->execute($values);
    
    $message = 'Settings updated successfully!';
}

$settings = getSiteSettings($db);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Settings - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="content">
            <div class="page-header">
                <h1>Site Settings</h1>
            </div>
            
            <?php if(!empty($message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <div class="content-card">
                <form method="POST" class="form" style="padding: 30px;">
                    <h3>General Settings</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Site Name</label>
                            <input type="text" name="site_name" class="form-control" value="<?php echo htmlspecialchars($settings['site_name']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Theme Color</label>
                            <input type="color" name="theme_color" class="form-control" value="<?php echo htmlspecialchars($settings['theme_color']); ?>">
                        </div>
                    </div>
                    
                    <h3 style="margin-top: 30px;">Contact Information</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Contact Email</label>
                            <input type="email" name="contact_email" class="form-control" value="<?php echo htmlspecialchars($settings['contact_email']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Contact Phone</label>
                            <input type="text" name="contact_phone" class="form-control" value="<?php echo htmlspecialchars($settings['contact_phone']); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($settings['address']); ?></textarea>
                    </div>
                    
                    <h3 style="margin-top: 30px;">Social Media</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Facebook URL</label>
                            <input type="url" name="facebook_url" class="form-control" value="<?php echo htmlspecialchars($settings['facebook_url']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Instagram URL</label>
                            <input type="url" name="instagram_url" class="form-control" value="<?php echo htmlspecialchars($settings['instagram_url']); ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>LinkedIn URL</label>
                            <input type="url" name="linkedin_url" class="form-control" value="<?php echo htmlspecialchars($settings['linkedin_url']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Twitter URL</label>
                            <input type="url" name="twitter_url" class="form-control" value="<?php echo htmlspecialchars($settings['twitter_url']); ?>">
                        </div>
                    </div>
                    
                    <h3 style="margin-top: 30px;">SEO Settings</h3>
                    
                    <div class="form-group">
                        <label>Meta Title</label>
                        <input type="text" name="meta_title" class="form-control" value="<?php echo htmlspecialchars($settings['meta_title']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="3"><?php echo htmlspecialchars($settings['meta_description']); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Meta Keywords</label>
                        <input type="text" name="meta_keywords" class="form-control" value="<?php echo htmlspecialchars($settings['meta_keywords']); ?>">
                    </div>
                    
                    <h3 style="margin-top: 30px;">Analytics & Tracking</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Google Analytics ID</label>
                            <input type="text" name="google_analytics_id" class="form-control" value="<?php echo htmlspecialchars($settings['google_analytics_id']); ?>" placeholder="G-XXXXXXXXXX">
                        </div>
                        
                        <div class="form-group">
                            <label>Facebook Pixel ID</label>
                            <input type="text" name="facebook_pixel_id" class="form-control" value="<?php echo htmlspecialchars($settings['facebook_pixel_id']); ?>">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-primary" style="margin-top: 30px;">
                        <i class="fas fa-save"></i> Save Settings
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <style>
        .form-row { display: flex; gap: 20px; }
        .form-row .form-group { flex: 1; }
        h3 { color: #000; font-size: 20px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #f0f0f0; }
    </style>
</body>
</html>

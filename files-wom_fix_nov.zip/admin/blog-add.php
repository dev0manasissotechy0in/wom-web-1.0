<?php
require_once '../config/config.php';

if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $slug = generateSlug($_POST['slug'] ?: $title);
    $content = $_POST['content'];
    $excerpt = sanitize($_POST['excerpt']);
    $category = sanitize($_POST['category']);
    $tags = sanitize($_POST['tags']);
    $status = $_POST['status'];
    $featured_image = sanitize($_POST['featured_image']);
    $author = sanitize($_POST['author']);
    
    try {
        $stmt = $db->prepare("INSERT INTO blogs (title, slug, content, excerpt, featured_image, author, category, tags, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $slug, $content, $excerpt, $featured_image, $author, $category, $tags, $status]);
        
        header('Location: blogs.php?msg=added');
        exit();
    } catch(PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Blog - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="content">
            <div class="page-header">
                <h1>Add New Blog</h1>
                <a href="blogs.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Back to Blogs</a>
            </div>
            
            <?php if(!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="content-card">
                <form method="POST" class="form">
                    <div class="form-row">
                        <div class="form-group" style="flex: 2;">
                            <label>Blog Title <span class="required">*</span></label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        
                        <div class="form-group" style="flex: 1;">
                            <label>Slug (URL)</label>
                            <input type="text" name="slug" class="form-control" placeholder="Auto-generated from title">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Featured Image URL</label>
                        <input type="url" name="featured_image" class="form-control" placeholder="https://example.com/image.jpg">
                    </div>
                    
                    <div class="form-group">
                        <label>Excerpt <span class="required">*</span></label>
                        <textarea name="excerpt" class="form-control" rows="3" required></textarea>
                        <small>Brief summary of the blog (150-200 characters recommended)</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Content <span class="required">*</span></label>
                        <textarea name="content" class="form-control" rows="15" required></textarea>
                        <small>You can use HTML tags for formatting</small>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Author <span class="required">*</span></label>
                            <input type="text" name="author" class="form-control" value="<?php echo $_SESSION['admin_name']; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Category <span class="required">*</span></label>
                            <input type="text" name="category" class="form-control" placeholder="e.g., SEO, Social Media" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Tags</label>
                            <input type="text" name="tags" class="form-control" placeholder="Comma separated tags">
                        </div>
                        
                        <div class="form-group">
                            <label>Status <span class="required">*</span></label>
                            <select name="status" class="form-control" required>
                                <option value="draft">Draft</option>
                                <option value="published">Published</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-save"></i> Save Blog
                        </button>
                        <a href="blogs.php" class="btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <style>
        .form-row {
            display: flex;
            gap: 20px;
        }
        
        .form-row .form-group {
            flex: 1;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn-secondary {
            background: #666;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-secondary:hover {
            background: #555;
        }
    </style>
</body>
</html>

<?php
session_start();
require_once 'config/config.php';

// Check for booking ID
$booking_id = (int)($_GET['booking_id'] ?? 0);

if (empty($booking_id)) {
    die("Invalid request");
}

// Get booking details
$stmt = $db->prepare("SELECT * FROM book_call WHERE id = ?");
$stmt->execute([$booking_id]);
$booking = $stmt->fetch();

if (!$booking) {
    die("Booking not found");
}

// PayPal details
$paypal_email = 'your-paypal@business.com';
$amount = $booking['amount'];
$currency = 'INR';
$success_url = 'https://self.manasissotechy.in/paypal-success.php';
$cancel_url = 'https://self.manasissotechy.in/book-call.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayPal Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        .payment-info {
            max-width: 500px;
            margin: 0 auto;
            padding: 40px;
            background: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: #667eea;
            margin-bottom: 20px;
        }
        .btn-pay {
            background: #00457c;
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn-pay:hover {
            background: #003366;
        }
    </style>
</head>
<body>
    <div class="payment-info">
        <h1>Complete Your Payment</h1>
        <p>Pay ₹<?php echo number_format($booking['amount'], 2); ?> to book your call</p>
        <p>Booking ID: #<?php echo $booking['id']; ?></p>
        
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
            <input type="hidden" name="cmd" value="_xclick">
            <input type="hidden" name="business" value="<?php echo $paypal_email; ?>">
            <input type="hidden" name="item_name" value="Call Booking">
            <input type="hidden" name="item_number" value="<?php echo $booking['id']; ?>">
            <input type="hidden" name="amount" value="<?php echo $amount; ?>">
            <input type="hidden" name="currency_code" value="<?php echo $currency; ?>">
            <input type="hidden" name="return" value="<?php echo $success_url; ?>">
            <input type="hidden" name="cancel_return" value="<?php echo $cancel_url; ?>">
            <input type="hidden" name="notify_url" value="https://self.manasissotechy.in/paypal-ipn.php">
            
            <button type="submit" class="btn-pay">
                <i class="fab fa-cc-paypal"></i> Pay with PayPal
            </button>
        </form>
    </div>
</body>
</html>

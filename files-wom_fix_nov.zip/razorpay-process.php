<?php
session_start();
require_once 'config/config.php';

$booking_id = (int)($_GET['booking_id'] ?? 0);

if (empty($booking_id)) {
    die("Invalid request");
}

$stmt = $db->prepare("SELECT * FROM book_call WHERE id = ?");
$stmt->execute([$booking_id]);
$booking = $stmt->fetch();

if (!$booking) {
    die("Booking not found");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RazorPay Payment</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        .payment-info {
            max-width: 500px;
            margin: 0 auto;
            padding: 40px;
            background: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: #667eea;
            margin-bottom: 20px;
        }
        .btn-pay {
            background: #008CBA;
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn-pay:hover {
            background: #007B9A;
        }
    </style>
</head>
<body>
    <div class="payment-info">
        <h1>Complete Your Payment</h1>
        <p>Pay ₹<?php echo number_format($booking['amount'], 2); ?> to book your call</p>
        <!--<p>Booking ID: #<?php echo $booking['id']; ?></p>-->
        
        <button id="rzp-button" class="btn-pay">Pay with RazorPay</button>
    </div>

    <script>
        document.getElementById('rzp-button').onclick = function(e){
            e.preventDefault();
            
            var options = {
                "key": "rzp_live_sNZBLWup032rTm", // Replace with your key
                "amount": <?php echo $booking['99900'] * 100; ?>, // Amount in paise
                "currency": "INR",
                "name": "Manasiss Otechy",
                "description": "Call Booking Fee",
                "image": "https://self.manasissotechy.in/logo.png", // Your logo URL
                "order_id": "", // For subscription use this
                "handler": function (response){
                    // Redirect to success page with payment details
                    window.location.href = 'https://self.manasissotechy.in/razorpay-success.php?payment_id=' + response.razorpay_payment_id + '&order_id=' + response.razorpay_order_id + '&booking_id=<?php echo $booking['id']; ?>';
                },
                "prefill": {
                    "name": "<?php echo htmlspecialchars($booking['name']); ?>",
                    "email": "<?php echo htmlspecialchars($booking['email']); ?>",
                    "contact": "<?php echo htmlspecialchars($booking['phone']); ?>"
                },
                "notes": {
                    "booking_id": "<?php echo $booking['id']; ?>"
                },
                "theme": {
                    "color": "#667eea"
                }
            };
            
            var rzp1 = new Razorpay(options);
            rzp1.open();

<?php require_once 'includes/header.php'; ?>

<style>
/* Contact Hero Section */
.contact-hero {
    background: linear-gradient(135deg, #1a1a1a 0%, #000 100%);
    color: white;
    padding: 100px 0 60px;
    text-align: center;
}

.contact-hero h1 {
    font-size: 3rem;
    margin-bottom: 15px;
    font-weight: 700;
}

.contact-hero p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Contact Section */
.contact-section {
    padding: 80px 0;
    background: #f8f9fa;
}

.contact-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 60px;
    max-width: 1200px;
    margin: 0 auto;
}

/* Contact Info */
.contact-info h2 {
    font-size: 2rem;
    margin-bottom: 20px;
    font-weight: 700;
}

.contact-info p {
    color: #666;
    margin-bottom: 30px;
    line-height: 1.6;
}

.contact-details {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.contact-item {
    display: flex;
    align-items: flex-start;
    gap: 20px;
    padding: 20px;
    background: #f8f8f8;
    border-radius: 10px;
    border: 2px solid #f0f0f0;
    transition: all 0.3s;
}

.contact-item:hover {
    border-color: #000;
    transform: translateX(5px);
}

.contact-icon {
    width: 50px;
    height: 50px;
    background: #000;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    font-size: 1.5rem;
    flex-shrink: 0;
}

.contact-item-content h3 {
    font-size: 1.2rem;
    margin-bottom: 8px;
    font-weight: 600;
    color: #000;
}

.contact-item-content p {
    margin: 0;
    color: #666;
}

.contact-item-content a {
    color: #000;
    text-decoration: none;
    font-weight: 600;
}
    transition: opacity 0.3s;
}

.contact-item-content a:hover {
    opacity
    text-decoration: underline;
}

/* Contact Form */
.contact-form-wrapper {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
}

.contact-form-wrapper h2 {
    font-size: 2rem;
    margin-bottom: 30px;
    font-weight: 700;
}

.form-group {
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
}

.form-group label .required {
    color: #e74c3c;
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 15px;
    font-family: inherit;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: #000;
    box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.1);
}

textarea.form-control {
    min-height: 150px;
    resize: vertical;
}

.btn-submit {
    width: 100%;
    padding: 16px;
    background: #000;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-submit:hover {
    background: #333;
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
}

.btn-submit:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
}

.social-links {
    display: flex
;
    gap: 15px;
    margin-top: 30px;
}

.social-link {
    width: 45px;
    height: 45px;
    background: #000;
    color: white;
    display: flex
;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    text-decoration: none;
    font-size: 1.2rem;
    transition: all 0.3s;
}

/* Alert Messages */
.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: none;
}

.alert.show {
    display: block;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* Responsive */
@media (max-width: 968px) {
    .contact-container {
        grid-template-columns: 1fr;
        gap: 40px;
    }
    
    .contact-hero {
        padding: 60px 0 40px;
    }
    
    .contact-hero h1 {
        font-size: 2rem;
    }
    
    .contact-form-wrapper {
        padding: 30px 20px;
    }
}

.map-section {
    margin-top: 80px;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.map-section iframe {
    width: 100%;
    height: 450px;
    border: none;
    display: block;
}

        .payment-options {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        .payment-option {
            flex: 1;
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-option:hover {
            border-color: #000;
        }
        .payment-option.active {
            border-color: #000;
            background: #f8f9fa;
        }
        .payment-option input {
            display: none;
        }
</style>

<!-- Hero Section -->
<section class="contact-hero">
    <div class="container">
        <h1>Book a Call</h1>
        <p>Fill in your details and pay to schedule a call with our expert</p>
    </div>
</section>

<!-- Contact Section -->
<section class="contact-section">
    <div class="container">
        <div class="contact-container">
           
            <!-- Contact Form -->
            <div class="contact-form-wrapper">
                <h2>Send Us a Message</h2>
                
                <!-- Alert Messages -->
                <div id="formAlert" class="alert"></div>
                
                            <form method="POST" action="process-booking.php">
                <div class="form-group">
                    <label for="name">Your Name *</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number *</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="enquiry">Your Enquiry/Requirements *</label>
                    <textarea id="enquiry" name="enquiry" class="form-control" placeholder="Tell us about your project or questions..." required></textarea>
                </div>
                
                <div class="payment-options">
                    <label class="payment-option">
                        <input type="radio" name="payment_method" value="PayPal" checked>
                        <h3>PayPal</h3>
                        <p>Secure payments</p>
                    </label>
                    
                    <label class="payment-option">
                        <input type="radio" name="payment_method" value="RazorPay">
                        <h3>RazorPay</h3>
                        <p>Cards/Net Banking</p>
                    </label>
                </div>
                
                <button type="submit" class="btn-primary">Book Call & Pay ₹999</button>
            </form>
            </div>
        </div>


    </div>
</section>


    <script>
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('active'));
                this.classList.add('active');
                this.querySelector('input').checked = true;
            });
            
            if (option.querySelector('input').checked) {
                option.classList.add('active');
            }
        });
    </script>



<?php require_once 'includes/footer.php'; ?>

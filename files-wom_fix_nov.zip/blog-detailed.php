<?php
require_once 'config/config.php';

// Get slug from URL
$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';

if(empty($slug)) {
    header('Location: /blogs');
    exit();
}

// Fetch blog by slug
try {
    $stmt = $db->prepare("SELECT * FROM blogs WHERE slug = ? AND status = 'published' LIMIT 1");
    $stmt->execute([$slug]);
    $blog = $stmt->fetch();
    
    if(!$blog) {
        header('Location: /error?code=404');
        exit();
    }
    
    // Update view count
    $update_views = $db->prepare("UPDATE blogs SET views = views + 1 WHERE id = ?");
    $update_views->execute([$blog['id']]);
    
} catch(PDOException $e) {
    error_log("Blog Error: " . $e->getMessage());
    die("Database error occurred");
}

// Get related blogs
try {
    $related_stmt = $db->prepare("SELECT * FROM blogs WHERE category = ? AND id != ? AND status = 'published' ORDER BY created_at DESC LIMIT 3");
    $related_stmt->execute([$blog['category'], $blog['id']]);
    $related_blogs = $related_stmt->fetchAll();
} catch(Exception $e) {
    $related_blogs = [];
}

// ==========================================
// PREPARE DYNAMIC SEO DATA FOR HEADER
// ==========================================
$customSeoData = [
    'title' => htmlspecialchars($blog['title']) . ' | ' . SITE_NAME,
    'description' => htmlspecialchars(strip_tags(substr($blog['content'], 0, 160))),
    'keywords' => htmlspecialchars($blog['category'] . ', ' . $blog['title'] . ', digital marketing, ' . SITE_NAME),
    'image' => !empty($blog['featured_image']) ? htmlspecialchars($blog['featured_image']) : SITE_URL . '/assets/images/default-blog.jpg',
    'url' => SITE_URL . '/blogs/' . $blog['slug'],
    'type' => 'article',
    'author' => htmlspecialchars($blog['author'] ?? 'Admin'),
    'published_date' => date('c', strtotime($blog['created_at'])),
    'modified_date' => date('c', strtotime($blog['updated_at'] ?? $blog['created_at'])),
    'category' => htmlspecialchars($blog['category'])
];
?>


<!-- Your existing blog HTML content -->

<?php require_once 'includes/header.php'; ?>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
body { font-family: 'Inter', sans-serif; background: #fff; color: #1a1a1a; line-height: 1.6; }
.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
.page-hero { background: linear-gradient(135deg, #1a1a1a 0%, #000 100%); color: white; padding: 60px 0 30px; text-align: center; }
.breadcrumb { color: rgba(255,255,255,0.8); font-size: 14px; margin-bottom: 15px; }
.breadcrumb a { color: white; text-decoration: none; }
.blog-detailed { padding: 60px 0; }
.blog-header { text-align: center; margin-bottom: 40px; }
.blog-header h1 { font-size: 2.5rem; margin-bottom: 20px; color: #000; font-weight: 700; }
.blog-meta { display: flex; justify-content: center; gap: 25px; flex-wrap: wrap; color: #666; font-size: 14px; }
.blog-meta span { display: flex; align-items: center; gap: 6px; }
.blog-meta i { color: #000; }
.blog-featured-image { max-width: 900px; margin: 40px auto; border-radius: 10px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
.blog-featured-image img { width: 100%; height: auto; display: block; }
.blog-content { max-width: 800px; margin: 0 auto; font-size: 18px; line-height: 1.8; }
.blog-content h2 { font-size: 1.8rem; margin: 35px 0 18px; color: #000; font-weight: 700; }
.blog-content h3 { font-size: 1.4rem; margin: 28px 0 14px; color: #1a1a1a; font-weight: 600; }
.blog-content p { margin-bottom: 18px; color: #333; }
.blog-tags { display: flex; flex-wrap: wrap; gap: 10px; max-width: 800px; margin: 40px auto; padding-top: 30px; border-top: 2px solid #e0e0e0; }
.tag { background: #f5f5f5; color: #000; padding: 6px 14px; border-radius: 20px; font-size: 13px; border: 1px solid #ddd; }
.blog-share { max-width: 800px; margin: 40px auto; text-align: center; }
.blog-share h3 { font-size: 1.2rem; margin-bottom: 18px; color: #000; }
.share-buttons { display: flex; justify-content: center; gap: 12px; flex-wrap: wrap; }
.share-btn { display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; border-radius: 5px; color: white; text-decoration: none; font-weight: 600; font-size: 14px; }
.share-facebook { background: #1877f2; }
.share-twitter { background: #1da1f2; }
.share-linkedin { background: #0077b5; }
.share-whatsapp { background: #25d366; }
.related-blogs { background: #f8f8f8; padding: 60px 0; margin-top: 50px; }
.related-blogs h2 { text-align: center; font-size: 2rem; margin-bottom: 40px; color: #000; }
.related-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; }
.blog-card { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); border: 2px solid transparent; transition: all 0.3s; }
.blog-card:hover { transform: translateY(-8px); box-shadow: 0 8px 25px rgba(0,0,0,0.15); border-color: #000; }
.blog-image { height: 200px; overflow: hidden; background: #f0f0f0; }
.blog-image img { width: 100%; height: 100%; object-fit: cover; }
.blog-category { position: absolute; top: 12px; left: 12px; background: #000; color: white; padding: 4px 12px; border-radius: 15px; font-size: 11px; font-weight: 600; }
.blog-card .blog-content { padding: 20px; }
.blog-card h3 { font-size: 1.2rem; margin-bottom: 10px; }
.blog-card h3 a { color: #1a1a1a; text-decoration: none; }
.blog-card p { color: #666; font-size: 14px; margin-bottom: 12px; }
.read-more { color: #000; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; font-size: 14px; }
.btn-primary { background: #000; color: white; padding: 12px 24px; border-radius: 5px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-weight: 600; border: 2px solid #000; }
.btn-primary:hover { background: white; color: #000; }
@media (max-width: 768px) {
    .blog-header h1 { font-size: 1.8rem; }
    .blog-content { font-size: 16px; }
}
</style>

<section class="page-hero">
    <div class="container">
        <div class="breadcrumb">
            <a href="/">Home</a> / 
            <a href="blogs.php">Blog</a> /
            <?php echo htmlspecialchars($blog['category']); ?>
        </div>
    </div>
</section>

<article class="blog-detailed">
    <div class="container">
        <header class="blog-header">
            <h1><?php echo htmlspecialchars($blog['title']); ?></h1>
            <div class="blog-meta">
                <span><i class="far fa-user"></i> <?php echo htmlspecialchars($blog['author']); ?></span>
                <span><i class="far fa-calendar"></i> <?php echo date('M d, Y', strtotime($blog['created_at'])); ?></span>
                <span><i class="far fa-eye"></i> <?php echo number_format($blog['views']); ?> views</span>
                
                            <!-- Clickable Category -->

            <a href="/blog-category?category=<?php echo urlencode($blog['category']); ?>"
                           <span><i class="far fa-folder"></i> <?php echo htmlspecialchars($blog['category']); ?></span>
            </a>
                
 
            </div>
        </header>
        
        <div class="blog-featured-image">
            <img src="<?php echo htmlspecialchars($blog['featured_image']); ?>" 
                 alt="<?php echo htmlspecialchars($blog['title']); ?>"
                 onerror="this.src='https://via.placeholder.com/900x400/000000/FFFFFF?text=<?php echo urlencode($blog['title']); ?>'">
        </div>
        
        <div class="blog-content">
            <?php echo $blog['content']; ?>
        </div>
        
        <?php if(!empty($blog['tags'])): ?>
        <div class="blog-tags">
            <?php 
            $tags = array_map('trim', explode(',', $blog['tags']));
            foreach($tags as $tag): 
                if(!empty($tag)):
            ?>
            <a href="/blog-tag?tag=<?php echo urlencode($tag); ?>" class="tag-item">

                <span class="tag"><i class="fas fa-tag"></i> 
                <?php echo htmlspecialchars($tag); ?>
                </span>
                    </a>            
            <?php 
                endif;
            endforeach; 
            ?>
        </div>
        <?php endif; ?>
        
        <div class="blog-share">
            <h3>Share this article</h3>
            <div class="share-buttons">
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('/blogs/' . $category_slug . '/' . $blog['slug']); ?>" 
                   target="_blank" class="share-btn share-facebook">
                    <i class="fab fa-facebook-f"></i> Facebook
                </a>
                <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode('/blogs/' . $category_slug . '/' . $blog['slug']); ?>&text=<?php echo urlencode($blog['title']); ?>" 
                   target="_blank" class="share-btn share-twitter">
                    <i class="fab fa-twitter"></i> Twitter
                </a>
                <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo urlencode('/blogs/' . $category_slug . '/' . $blog['slug']); ?>" 
                   target="_blank" class="share-btn share-linkedin">
                    <i class="fab fa-linkedin-in"></i> LinkedIn
                </a>
                <a href="https://wa.me/?text=<?php echo urlencode($blog['title'] . ' - /blogs/' . $category_slug . '/' . $blog['slug']); ?>" 
                   target="_blank" class="share-btn share-whatsapp">
                    <i class="fab fa-whatsapp"></i> WhatsApp
                </a>
            </div>
        </div>
    </div>
</article>

<?php if(!empty($related_blogs)): ?>
<section class="related-blogs">
    <div class="container">
        <h2>Related Articles</h2>
        <div class="related-grid">
            <?php foreach($related_blogs as $related): 
                $rel_category_slug = strtolower(str_replace(' ', '-', $related['category']));
            ?>
                <article class="blog-card">
                    <div class="blog-image" style="position: relative;">
                        <img src="<?php echo htmlspecialchars($related['featured_image']); ?>" 
                             alt="<?php echo htmlspecialchars($related['title']); ?>"
                             onerror="this.src='https://via.placeholder.com/400x200/000000/FFFFFF?text=Blog'">
                        <span class="blog-category"><?php echo htmlspecialchars($related['category']); ?></span>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta" style="margin-bottom: 12px;">
                            <span><i class="far fa-calendar"></i> <?php echo date('M d, Y', strtotime($related['created_at'])); ?></span>
                        </div>
                        <h3>
                            <a href="/blogs/<?php echo $rel_category_slug; ?>/<?php echo $related['slug']; ?>">
                                <?php echo htmlspecialchars($related['title']); ?>
                            </a>
                        </h3>
                        <p><?php echo htmlspecialchars(substr($related['excerpt'], 0, 100)); ?>...</p>
                        <a href="/blogs/<?php echo $rel_category_slug; ?>/<?php echo $related['slug']; ?>" class="read-more">
                            Read More <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="container" style="text-align: center; padding: 50px 0;">
    <a href="blogs.php" class="btn-primary">
        <i class="fas fa-arrow-left"></i> Back to All Blogs
    </a>
</div>

<?php require_once 'includes/footer.php'; ?>

<?php
session_start();

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php-errors.log');

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Site Constants
define('SITE_URL', 'https://wallofmarketing.co');
define('SITE_NAME', 'Wall of Marketing');
define('ADMIN_EMAIL', 'connect@wallofmarketing.co');

// Security
define('SECURE_KEY', 'your-secure-random-key-here-change-this');

// Database
require_once __DIR__ . '/database.php';
$database = new Database();
$db = $database->connect();

// Functions
require_once __DIR__ . '/../includes/functions.php';

// Custom Error Handler
set_error_handler('customErrorHandler');
set_exception_handler('customExceptionHandler');

function customErrorHandler($errno, $errstr, $errfile, $errline) {
    global $db;
    $error_message = "Error [$errno]: $errstr in $errfile on line $errline";
    error_log($error_message);
    
    $stmt = $db->prepare("INSERT INTO error_logs (error_type, error_message, file_path, line_number, user_ip, request_url) 
                          VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute(['PHP Error', $errstr, $errfile, $errline, $_SERVER['REMOTE_ADDR'], $_SERVER['REQUEST_URI']]);
    
    if ($errno === E_ERROR || $errno === E_USER_ERROR) {
        header("Location: /error.php?code=500");
        exit();
    }
}

function customExceptionHandler($exception) {
    global $db;
    $error_message = "Uncaught Exception: " . $exception->getMessage();
    error_log($error_message);
    
    $stmt = $db->prepare("INSERT INTO error_logs (error_type, error_message, file_path, line_number, user_ip, request_url) 
                          VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute(['Exception', $exception->getMessage(), $exception->getFile(), $exception->getLine(), $_SERVER['REMOTE_ADDR'], $_SERVER['REQUEST_URI']]);
    
    header("Location: /error.php?code=500");
    exit();
}
?>

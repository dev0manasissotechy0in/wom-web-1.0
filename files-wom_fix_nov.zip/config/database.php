<?php
class Database {
    private $host = 'sg2plzcpnl492040.prod.sin2.secureserver.net';
    private $db_name = 'wom_self';
    private $username = 'wom_self_u';
    private $password = 't??B)M{bfb}H';
    public $conn;

    public function connect() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            $this->logError("Connection Error: " . $e->getMessage());
            die("Database connection failed. Please check your configuration.");
        }
        
        return $this->conn;
    }

    private function logError($message) {
        $logDir = __DIR__ . '/../logs';
        if (!file_exists($logDir)) {
            mkdir($logDir, 0777, true);
        }
        error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, $logDir . '/errors.log');
    }
}
?>

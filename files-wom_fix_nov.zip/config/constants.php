<?php
/**
 * Site Constants & Configuration
 * All global constants and settings for Digital Marketing Pro
 */

// ================================================
// SITE INFORMATION
// ================================================
define('SITE_NAME', 'Digital Marketing Pro');
define('SITE_TAGLINE', 'Transform Your Digital Presence');
define('SITE_URL', 'https://self.manasissotechy.in');
define('SITE_DESCRIPTION', 'Leading digital marketing agency providing SEO, social media marketing, PPC, content marketing, and comprehensive digital solutions for businesses.');
define('SITE_KEYWORDS', 'digital marketing, SEO, social media marketing, PPC, content marketing, email marketing, digital agency');

// ================================================
// CONTACT INFORMATION
// ================================================
define('CONTACT_EMAIL', '[email protected]');
define('CONTACT_PHONE', '+91 1234567890');
define('CONTACT_ADDRESS', 'Mumbai, Maharashtra, India');
define('ADMIN_EMAIL', '[email protected]');

// ================================================
// SOCIAL MEDIA LINKS
// ================================================
define('SOCIAL_FACEBOOK', 'https://facebook.com/yourpage');
define('SOCIAL_TWITTER', 'https://twitter.com/yourhandle');
define('SOCIAL_LINKEDIN', 'https://linkedin.com/company/yourcompany');
define('SOCIAL_INSTAGRAM', 'https://instagram.com/yourhandle');
define('SOCIAL_YOUTUBE', 'https://youtube.com/yourchannel');

// ================================================
// BUSINESS HOURS
// ================================================
define('BUSINESS_HOURS_WEEKDAY', 'Monday - Friday: 9:00 AM - 6:00 PM');
define('BUSINESS_HOURS_SATURDAY', 'Saturday: 10:00 AM - 4:00 PM');
define('BUSINESS_HOURS_SUNDAY', 'Sunday: Closed');

// ================================================
// FILE PATHS
// ================================================
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');
define('ASSETS_PATH', __DIR__ . '/../assets/');
define('ASSETS_URL', SITE_URL . '/assets/');

// ================================================
// IMAGES & MEDIA
// ================================================
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']);
define('DEFAULT_IMAGE', SITE_URL . '/assets/images/default.jpg');
define('LOGO_URL', SITE_URL . '/assets/images/logo.png');
define('FAVICON_URL', SITE_URL . '/assets/images/favicon.ico');

// ================================================
// PAGINATION & LIMITS
// ================================================
define('POSTS_PER_PAGE', 12);
define('BLOGS_PER_PAGE', 9);
define('CASE_STUDIES_PER_PAGE', 6);
define('TESTIMONIALS_PER_PAGE', 6);
define('RELATED_POSTS_LIMIT', 3);

// ================================================
// SEO SETTINGS
// ================================================
define('META_TITLE_SUFFIX', ' | ' . SITE_NAME);
define('DEFAULT_META_DESCRIPTION', SITE_DESCRIPTION);
define('DEFAULT_META_IMAGE', LOGO_URL);
define('META_ROBOTS', 'index, follow');
define('GOOGLE_ANALYTICS_ID', 'G-XXXXXXXXXX'); // Replace with your GA ID
define('GOOGLE_SITE_VERIFICATION', ''); // Google Search Console verification
define('FACEBOOK_APP_ID', ''); // Facebook App ID for Open Graph

// ================================================
// API KEYS & INTEGRATIONS
// ================================================
// Google Services
define('GOOGLE_MAPS_API_KEY', ''); // For location maps
define('GOOGLE_RECAPTCHA_SITE_KEY', ''); // reCAPTCHA v3
define('GOOGLE_RECAPTCHA_SECRET_KEY', '');

// Email Marketing
define('MAILCHIMP_API_KEY', '');
define('MAILCHIMP_LIST_ID', '');

// Social Media APIs
define('FACEBOOK_PAGE_ID', '');
define('FACEBOOK_ACCESS_TOKEN', '');

// ================================================
// SESSION & SECURITY
// ================================================
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds
define('LOGIN_ATTEMPTS_LIMIT', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes in seconds
define('PASSWORD_MIN_LENGTH', 8);
define('CSRF_TOKEN_EXPIRY', 3600); // 1 hour

// ================================================
// DATE & TIME
// ================================================
define('TIMEZONE', 'Asia/Kolkata');
define('DATE_FORMAT', 'F j, Y'); // January 1, 2025
define('TIME_FORMAT', 'g:i A'); // 3:30 PM
define('DATETIME_FORMAT', 'F j, Y \a\t g:i A'); // January 1, 2025 at 3:30 PM

// Set default timezone
date_default_timezone_set(TIMEZONE);

// ================================================
// FEATURES & TOGGLES
// ================================================
define('FEATURE_BLOG', true);
define('FEATURE_CASE_STUDIES', true);
define('FEATURE_NEWSLETTER', true);
define('FEATURE_TESTIMONIALS', true);
define('FEATURE_PORTFOLIO', true);
define('FEATURE_COMMENTS', false);
define('FEATURE_RATINGS', true);
define('MAINTENANCE_MODE', false);

// ================================================
// ADMIN SETTINGS
// ================================================
define('ADMIN_ITEMS_PER_PAGE', 20);
define('ADMIN_SESSION_TIMEOUT', 7200); // 2 hours
define('ADMIN_PANEL_NAME', 'DMP Admin');
define('ADMIN_LOGIN_URL', SITE_URL . '/admin/login.php');

// ================================================
// CACHE SETTINGS
// ================================================
define('CACHE_ENABLED', true);
define('CACHE_DURATION', 3600); // 1 hour
define('CACHE_PATH', __DIR__ . '/../cache/');

// ================================================
// ERROR HANDLING
// ================================================
define('DISPLAY_ERRORS', false); // Set to false in production
define('LOG_ERRORS', true);
define('ERROR_LOG_PATH', __DIR__ . '/../logs/error.log');

// ================================================
// EMAIL SETTINGS (for mail() function)
// ================================================
define('EMAIL_FROM_NAME', SITE_NAME);
define('EMAIL_FROM_ADDRESS', CONTACT_EMAIL);
define('EMAIL_REPLY_TO', CONTACT_EMAIL);

// ================================================
// RATE LIMITING
// ================================================
define('RATE_LIMIT_REQUESTS', 100); // Max requests per minute
define('RATE_LIMIT_PERIOD', 60); // Time period in seconds

// ================================================
// CONTENT SETTINGS
// ================================================
define('EXCERPT_LENGTH', 200); // Characters
define('MAX_TITLE_LENGTH', 100);
define('MAX_META_DESCRIPTION_LENGTH', 160);
define('MIN_CONTENT_LENGTH', 300);

// ================================================
// CUSTOM POST TYPES SLUGS
// ================================================
define('BLOG_SLUG', 'blogs');
define('CASE_STUDY_SLUG', 'case-studies');
define('SERVICE_SLUG', 'services');
define('PORTFOLIO_SLUG', 'portfolio');

// ================================================
// STATUS CODES
// ================================================
define('STATUS_DRAFT', 'draft');
define('STATUS_PUBLISHED', 'published');
define('STATUS_PENDING', 'pending');
define('STATUS_ARCHIVED', 'archived');

// ================================================
// USER ROLES (if implementing user system)
// ================================================
define('ROLE_ADMIN', 'admin');
define('ROLE_EDITOR', 'editor');
define('ROLE_AUTHOR', 'author');
define('ROLE_SUBSCRIBER', 'subscriber');

// ================================================
// PRICING & CURRENCY
// ================================================
define('CURRENCY_SYMBOL', '₹');
define('CURRENCY_CODE', 'INR');
define('CURRENCY_POSITION', 'before'); // before or after number

// ================================================
// NOTIFICATION SETTINGS
// ================================================
define('NOTIFY_ADMIN_NEW_INQUIRY', true);
define('NOTIFY_ADMIN_NEW_SUBSCRIBER', true);
define('NOTIFY_USER_CONFIRMATION', true);

// ================================================
// EXTERNAL LINKS
// ================================================
define('TERMS_URL', SITE_URL . '/terms-conditions');
define('PRIVACY_URL', SITE_URL . '/privacy-policy');
define('COOKIE_URL', SITE_URL . '/cookie-policy');
define('DISCLAIMER_URL', SITE_URL . '/disclaimer');

// ================================================
// WHATSAPP & CALL TO ACTION
// ================================================
define('WHATSAPP_NUMBER', '919876543210'); // Without + sign
define('WHATSAPP_MESSAGE', 'Hi! I would like to know more about your services.');
define('CTA_PHONE', CONTACT_PHONE);
define('CTA_EMAIL', CONTACT_EMAIL);

// ================================================
// DEVELOPMENT MODE
// ================================================
define('DEBUG_MODE', false); // Set to false in production
define('DEV_MODE', false); // Set to false in production

// Error reporting based on mode
if(DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    if(defined('ERROR_LOG_PATH')) {
        ini_set('error_log', ERROR_LOG_PATH);
    }
}

// ================================================
// HELPER FUNCTIONS
// ================================================

/**
 * Get full asset URL
 */
function asset($path) {
    return ASSETS_URL . ltrim($path, '/');
}

/**
 * Get full upload URL
 */
function upload($path) {
    return UPLOAD_URL . ltrim($path, '/');
}

/**
 * Get site URL
 */
function url($path = '') {
    return SITE_URL . '/' . ltrim($path, '/');
}

/**
 * Format currency
 */
function format_currency($amount) {
    if(CURRENCY_POSITION == 'before') {
        return CURRENCY_SYMBOL . number_format($amount, 2);
    } else {
        return number_format($amount, 2) . CURRENCY_SYMBOL;
    }
}

/**
 * Format date
 */
function format_date($date, $format = DATE_FORMAT) {
    return date($format, strtotime($date));
}

/**
 * Get excerpt
 */
function get_excerpt($text, $length = EXCERPT_LENGTH) {
    if(strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

/**
 * Sanitize output
 */
function sanitize($text) {
    return htmlspecialchars(strip_tags(trim($text)), ENT_QUOTES, 'UTF-8');
}

/**
 * Check if feature is enabled
 */
function is_feature_enabled($feature) {
    $constant = 'FEATURE_' . strtoupper($feature);
    return defined($constant) && constant($constant) === true;
}

/**
 * Get WhatsApp URL
 */
function get_whatsapp_url($message = null) {
    $msg = $message ?? WHATSAPP_MESSAGE;
    return 'https://wa.me/' . WHATSAPP_NUMBER . '?text=' . urlencode($msg);
}

/**
 * Check if in maintenance mode
 */
function is_maintenance_mode() {
    return MAINTENANCE_MODE === true;
}

?>

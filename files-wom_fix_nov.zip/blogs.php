<?php 
require_once 'includes/header.php';

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 9;
$offset = ($page - 1) * $per_page;

// SEO meta data
$customSeoData = [
    'title' => 'Blog - Latest Digital Marketing Insights | ' . SITE_NAME,
    'description' => 'Stay updated with the latest digital marketing trends, tips, and strategies. Expert insights from industry professionals on SEO, social media, content marketing, and more.',
    'keywords' => 'digital marketing blog, SEO tips, social media strategies, marketing guides, content marketing, digital trends',
    'url' => SITE_URL . '/blogs',
    'type' => 'blog',
    'image' => SITE_URL . '/assets/images/blog-og.jpg'
];

// Get total blogs
try {
    $total_stmt = $db->query("SELECT COUNT(*) as total FROM blogs WHERE status = 'published'");
    $total = $total_stmt->fetch()['total'];
    $total_pages = ceil($total / $per_page);
    
    // Fetch blogs
    $stmt = $db->prepare("SELECT * FROM blogs WHERE status = 'published' ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $per_page, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    error_log("Blogs page error: " . $e->getMessage());
    $blogs = [];
    $total = 0;
    $total_pages = 0;
}
?>

<style>
/* Hero Section */
.blog-hero {
    background: linear-gradient(135deg, #1a1a1a 0%, #000 100%);
    color: white;
    padding: 100px 0 60px;
    text-align: center;
}

.blog-hero h1 {
    font-size: 3rem;
    margin-bottom: 15px;
    font-weight: 700;
}

.blog-hero p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Blogs Container */
.blogs-section {
    padding: 80px 0;
    background: #f8f9fa;
}

.blogs-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 40px;
    margin-bottom: 60px;
}

/* Blog Card */
.blog-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.4s ease;
    display: flex;
    flex-direction: column;
}

.blog-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
}

/* Blog Image */
.blog-image {
    position: relative;
    overflow: hidden;
    height: 250px;
}

.blog-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.4s ease;
}

.blog-card:hover .blog-image img {
    transform: scale(1.1);
}

.blog-category {
    position: absolute;
    top: 15px;
    left: 15px;
    background: rgba(0, 0, 0, 0.85);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    z-index: 2;
}

/* Blog Content */
.blog-content {
    padding: 25px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.blog-meta {
    display: flex;
    gap: 20px;
    margin-bottom: 15px;
    font-size: 13px;
    color: #666;
}

.blog-meta span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.blog-meta i {
    color: #000;
}

.blog-content h3 {
    font-size: 1.4rem;
    margin-bottom: 12px;
    font-weight: 700;
    line-height: 1.4;
}

.blog-content h3 a {
    color: #1a1a1a;
    text-decoration: none;
    transition: color 0.3s ease;
}

.blog-content h3 a:hover {
    color: #000;
}

.blog-excerpt {
    color: #666;
    line-height: 1.6;
    margin-bottom: 20px;
    font-size: 14px;
    flex-grow: 1;
}

.read-more {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #000;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: all 0.3s ease;
    align-self: flex-start;
}

.read-more:hover {
    gap: 12px;
}

.read-more i {
    font-size: 12px;
    transition: transform 0.3s ease;
}

.read-more:hover i {
    transform: translateX(4px);
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 60px;
}

.pagination a,
.pagination span {
    padding: 10px 18px;
    background: white;
    color: #333;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s ease;
    border: 2px solid #e0e0e0;
}

.pagination a:hover {
    background: #000;
    color: white;
    border-color: #000;
}

.pagination .current {
    background: #000;
    color: white;
    border-color: #000;
}

.pagination .disabled {
    opacity: 0.5;
    cursor: not-allowed;
    pointer-events: none;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 80px 20px;
}

.empty-state i {
    font-size: 4rem;
    color: #ddd;
    margin-bottom: 20px;
}

.empty-state h2 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #333;
}

.empty-state p {
    color: #666;
    font-size: 1.1rem;
}

/* Responsive Design */
@media (max-width: 768px) {
    .blog-hero {
        padding: 60px 0 40px;
    }
    
    .blog-hero h1 {
        font-size: 2rem;
    }
    
    .blog-hero p {
        font-size: 1rem;
    }
    
    .blogs-section {
        padding: 50px 0;
    }
    
    .blogs-grid {
        grid-template-columns: 1fr;
        gap: 30px;
    }
    
    .blog-image {
        height: 200px;
    }
    
    .blog-content {
        padding: 20px;
    }
    
    .blog-content h3 {
        font-size: 1.2rem;
    }
}

@media (max-width: 480px) {
    .blog-hero h1 {
        font-size: 1.6rem;
    }
    
    .blog-meta {
        flex-direction: column;
        gap: 10px;
    }
    
    .pagination {
        flex-wrap: wrap;
        gap: 8px;
    }
    
    .pagination a,
    .pagination span {
        padding: 8px 14px;
        font-size: 14px;
    }
}
</style>

<!-- Hero Section -->
<section class="blog-hero">
    <div class="container">
        <h1>Our Blog</h1>
        <p>Latest insights and updates<?php if($total > 0): ?> • <?php echo $total; ?> articles<?php endif; ?></p>
    </div>
</section>

<!-- Blogs Section -->
<section class="blogs-section">
    <div class="container">
        <?php if (!empty($blogs)): ?>
            <div class="blogs-grid">
                <?php foreach ($blogs as $blog): ?>
                <article class="blog-card">
                    <div class="blog-image">
                        <img src="<?php echo htmlspecialchars($blog['featured_image'] ?? ''); ?>" 
                             alt="<?php echo htmlspecialchars($blog['title'] ?? ''); ?>"
                             onerror="this.src='https://via.placeholder.com/600x400/000000/FFFFFF?text=Blog+Post'">
                        <span class="blog-category"><?php echo htmlspecialchars($blog['category'] ?? 'General'); ?></span>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <span>
                                <i class="far fa-calendar"></i> 
                                <?php echo date('M d, Y', strtotime($blog['created_at'])); ?>
                            </span>
                            <span>
                                <i class="far fa-eye"></i> 
                                <?php echo number_format($blog['views'] ?? 0); ?> views
                            </span>
                        </div>
                        <h3>
                            <a href="/blogs/<?php echo htmlspecialchars($blog['category'] ?? 'general'); ?>/<?php echo htmlspecialchars($blog['slug'] ?? ''); ?>">
                                <?php echo htmlspecialchars($blog['title'] ?? ''); ?>
                            </a>
                        </h3>
                        <p class="blog-excerpt">
                            <?php echo htmlspecialchars(substr($blog['excerpt'] ?? '', 0, 150)); ?>...
                        </p>
                        <a href="/blogs/<?php echo htmlspecialchars($blog['category'] ?? 'general'); ?>/<?php echo htmlspecialchars($blog['slug'] ?? ''); ?>" class="read-more">
                            Read More <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <!-- Previous Button -->
                <?php if ($page > 1): ?>
                    <a href="/blogs?page=<?php echo ($page - 1); ?>">
                        <i class="fas fa-chevron-left"></i> Previous
                    </a>
                <?php else: ?>
                    <span class="disabled">
                        <i class="fas fa-chevron-left"></i> Previous
                    </span>
                <?php endif; ?>

                <!-- Page Numbers -->
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if ($i == 1 || $i == $total_pages || abs($i - $page) <= 2): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="/blogs?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php elseif (abs($i - $page) == 3): ?>
                        <span>...</span>
                    <?php endif; ?>
                <?php endfor; ?>

                <!-- Next Button -->
                <?php if ($page < $total_pages): ?>
                    <a href="/blogs?page=<?php echo ($page + 1); ?>">
                        Next <i class="fas fa-chevron-right"></i>
                    </a>
                <?php else: ?>
                    <span class="disabled">
                        Next <i class="fas fa-chevron-right"></i>
                    </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        <?php else: ?>
            <!-- Empty State -->
            <div class="empty-state">
                <i class="fas fa-file-alt"></i>
                <h2>No Blog Posts Yet</h2>
                <p>Check back soon for the latest insights and updates!</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>

<?php
// Security headers
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'logs/php_errors.log');

// Rate limiting
function checkRateLimit($identifier, $max_attempts = 5, $timeframe = 300) {
    $rate_limit_file = 'rate_limit.txt';
    $time = time();
    $attempts = 0;
    
    // Read attempts
    if (file_exists($rate_limit_file)) {
        $attempts_log = file($rate_limit_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($attempts_log as $log) {
            list($ip, $time_attempted) = explode('|', $log);
            if ($ip === $identifier && $time_attempted > $time - $timeframe) {
                $attempts++;
            }
        }
    }
    
    if ($attempts >= $max_attempts) {
        return false;
    }
    
    // Log attempt
    file_put_contents($rate_limit_file, $identifier . '|' . $time . "\n", FILE_APPEND | LOCK_EX);
    return true;
}

// Sanitize input
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

// Validate input
$ip = $_SERVER['REMOTE_ADDR'];
checkRateLimit($ip, 5, 900);

$name = sanitize($_POST['name'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$phone = sanitize($_POST['phone'] ?? '');
$enquiry = sanitize($_POST['enquiry'] ?? '');
$payment_method = sanitize($_POST['payment_method'] ?? '');

if (empty($name) || empty($email) || empty($phone) || empty($enquiry) || empty($payment_method)) {
    die(json_encode(['error' => 'All fields are required']));
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die(json_encode(['error' => 'Invalid email format']));
}

// Validate phone (Indian format)
if (!preg_match('/^\d{10}$/', $phone)) {
    die(json_encode(['error' => 'Invalid phone number']));
}

// Database connection
try {
    $db = new PDO(
        'mysql:host=sg2plzcpnl492040.prod.sin2.secureserver.net;dbname=wom_self;charset=utf8mb4',
        'wom_self_u',
        't??B)M{bfb}H',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch(PDOException $e) {
    error_log('Database connection error: ' . $e->getMessage());
    die(json_encode(['error' => 'Database error']));
}

// Get payment method id
$stmt = $db->prepare("SELECT id FROM payment_methods WHERE name = ?");
$stmt->execute([$payment_method]);
$method = $stmt->fetch();

if (!$method) {
    die(json_encode(['error' => 'Invalid payment method']));
}

$payment_method_id = $method['id'];

// Insert into database
// After creating booking, set expiry time (e.g., 1 hour)
$stmt = $db->prepare("INSERT INTO book_call (name, email, phone, enquiry, payment_method_id, amount, payment_status, expiry_time) VALUES (?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
$stmt->execute([$name, $email, $phone, $enquiry, $payment_method_id, 999.00, 'pending']);

$booking_id = $db->lastInsertId();

// Generate Calendly link
$calendly_link = "https://calendly.com/manasissotechy?booking_id=" . $booking_id;
$db->prepare("UPDATE book_call SET calendly_link = ? WHERE id = ?")->execute([$calendly_link, $booking_id]);

// Prepare response
echo json_encode([
    'success' => true,
    'booking_id' => $booking_id,
    'calendly_link' => $calendly_link,
    'payment_method' => $payment_method
]);
?>

<?php
function renderSeoMeta($db, $page, $customSeoData = []) {
    // Default values
    $site_name = defined('SITE_NAME') ? SITE_NAME : 'Wall of Marketing';
    $site_url = defined('SITE_URL') ? SITE_URL : 'https://self.manasissotechy.in';
    
    // Initialize SEO variables with defaults
    $title = $site_name . ' - Transform Your Digital Presence';
    $description = 'Leading digital marketing agency providing SEO, social media marketing, PPC, and comprehensive digital solutions.';
    $keywords = 'digital marketing, SEO, social media, PPC, content marketing';
    $image = $site_url . '/assets/images/og-image.jpg';
    $url = $site_url . $_SERVER['REQUEST_URI'];
    $type = 'website';
    $author = $site_name;
    $published_date = date('c');
    $modified_date = date('c');
    $category = '';
    
    // If custom SEO data is provided (for blog posts, case studies, etc.)
    if (!empty($customSeoData)) {
        $title = $customSeoData['title'] ?? $title;
        $description = $customSeoData['description'] ?? $description;
        $keywords = $customSeoData['keywords'] ?? $keywords;
        $image = $customSeoData['image'] ?? $image;
        $url = $customSeoData['url'] ?? $url;
        $type = $customSeoData['type'] ?? $type;
        $author = $customSeoData['author'] ?? $author;
        $published_date = $customSeoData['published_date'] ?? $published_date;
        $modified_date = $customSeoData['modified_date'] ?? $modified_date;
        $category = $customSeoData['category'] ?? '';
    } else {
        // Page-specific defaults
        switch($page) {
            case 'index':
                $title = $site_name . ' - Transform Your Digital Presence';
                $description = 'Leading digital marketing agency specializing in SEO, social media marketing, PPC, and content marketing. Drive real results for your business.';
                $keywords = 'digital marketing agency, SEO services, social media marketing, PPC advertising, content marketing';
                break;
                
            case 'about':
                $title = 'About Us - ' . $site_name;
                $description = 'Learn about our team, mission, and values. We are passionate about helping businesses succeed online through innovative digital marketing strategies.';
                $keywords = 'about us, digital marketing team, marketing agency, our story';
                break;
                
            case 'services':
                $title = 'Our Services - Digital Marketing Solutions | ' . $site_name;
                $description = 'Comprehensive digital marketing services including SEO, social media marketing, PPC, content marketing, email marketing, and analytics.';
                $keywords = 'digital marketing services, SEO optimization, social media management, PPC campaigns, content strategy';
                break;
                
            case 'blogs':
                $title = 'Blog - Latest Digital Marketing Insights | ' . $site_name;
                $description = 'Stay updated with the latest digital marketing trends, tips, and strategies from industry experts. Learn how to grow your business online.';
                $keywords = 'digital marketing blog, SEO tips, social media strategies, marketing guides, industry insights';
                $type = 'blog';
                break;
                
            case 'contact':
                $title = 'Contact Us - Get In Touch | ' . $site_name;
                $description = 'Get in touch with our team. We\'re here to help you grow your business online. Schedule a free consultation today.';
                $keywords = 'contact us, get in touch, digital marketing consultation, free quote';
                break;
                
            case 'case-studies':
                $title = 'Case Studies - Our Success Stories | ' . $site_name;
                $description = 'Explore our portfolio of successful digital marketing campaigns and case studies. See how we helped businesses achieve their goals.';
                $keywords = 'case studies, success stories, digital marketing results, portfolio, client testimonials';
                break;
        }
    }
    
    ?>
    <!-- Primary Meta Tags -->
    <title><?php echo $title; ?></title>
    <meta name="title" content="<?php echo $title; ?>">
    <meta name="description" content="<?php echo $description; ?>">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <meta name="author" content="<?php echo $author; ?>">
    <meta name="robots" content="index, follow">
    <meta name="googlebot" content="index, follow">
    <link rel="canonical" href="<?php echo $url; ?>">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="<?php echo $type; ?>">
    <meta property="og:url" content="<?php echo $url; ?>">
    <meta property="og:title" content="<?php echo $title; ?>">
    <meta property="og:description" content="<?php echo $description; ?>">
    <meta property="og:image" content="<?php echo $image; ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:site_name" content="<?php echo $site_name; ?>">
    <meta property="og:locale" content="en_US">
    
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo $url; ?>">
    <meta name="twitter:title" content="<?php echo $title; ?>">
    <meta name="twitter:description" content="<?php echo $description; ?>">
    <meta name="twitter:image" content="<?php echo $image; ?>">
    <meta name="twitter:creator" content="@<?php echo $site_name; ?>">
    
    <?php if ($type === 'article'): ?>
    <!-- Article Meta Tags -->
    <meta property="article:published_time" content="<?php echo $published_date; ?>">
    <meta property="article:modified_time" content="<?php echo $modified_date; ?>">
    <meta property="article:author" content="<?php echo $author; ?>">
    <?php if (!empty($category)): ?>
    <meta property="article:section" content="<?php echo $category; ?>">
    <meta property="article:tag" content="<?php echo $keywords; ?>">
    <?php endif; ?>
    <?php endif; ?>
    
    <!-- Schema.org JSON-LD for SEO -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "<?php echo $type === 'article' ? 'BlogPosting' : ($type === 'blog' ? 'Blog' : 'WebPage'); ?>",
        "headline": <?php echo json_encode($title); ?>,
        "description": <?php echo json_encode($description); ?>,
        "image": "<?php echo $image; ?>",
        "url": "<?php echo $url; ?>",
        <?php if ($type === 'article'): ?>
        "datePublished": "<?php echo $published_date; ?>",
        "dateModified": "<?php echo $modified_date; ?>",
        "author": {
            "@type": "Person",
            "name": <?php echo json_encode($author); ?>
        },
        <?php if (!empty($category)): ?>
        "articleSection": <?php echo json_encode($category); ?>,
        <?php endif; ?>
        "keywords": <?php echo json_encode($keywords); ?>,
        <?php endif; ?>
        "publisher": {
            "@type": "Organization",
            "name": "<?php echo $site_name; ?>",
            "logo": {
                "@type": "ImageObject",
                "url": "<?php echo $site_url; ?>/assets/images/logo.png"
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "<?php echo $url; ?>"
        }
    }
    </script>
    
    <?php if ($type === 'blog' || $type === 'article'): ?>
    <!-- Additional Schema for Breadcrumbs -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": "<?php echo $site_url; ?>"
            },
            {
                "@type": "ListItem",
                "position": 2,
                "name": "Blog",
                "item": "<?php echo $site_url; ?>/blogs"
            }
            <?php if ($type === 'article' && !empty($category)): ?>
            ,{
                "@type": "ListItem",
                "position": 3,
                "name": <?php echo json_encode($category); ?>,
                "item": "<?php echo $site_url; ?>/blogs/<?php echo strtolower($category); ?>"
            }
            <?php endif; ?>
        ]
    }
    </script>
    <?php endif; ?>
    <?php
}
?>

<?php
declare(strict_types=1);

function getTrackingScripts(array $consent): string {
    $scripts = [];
    
    // Google Analytics 4 - Only if analytics consent given
    if ($consent['analytics']) {
        $scripts[] = <<<HTML
        <!-- Google Analytics 4 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-YOUR-ID"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-YOUR-ID', {
                'anonymize_ip': true,
                'cookie_flags': 'SameSite=None;Secure'
            });
        </script>
HTML;
    }
    
    // Meta Pixel - Only if marketing consent given
    if ($consent['marketing']) {
        $scripts[] = <<<HTML
        <!-- Meta Pixel -->
        <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', 'YOUR-PIXEL-ID');
        fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=YOUR-PIXEL-ID&ev=PageView&noscript=1"/>
        </noscript>
HTML;
    }
    
    return implode("\n", $scripts);
}

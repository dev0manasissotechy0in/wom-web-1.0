<?php
// admin/index.php - Redirect handler
header('Location: dashboard.php');
exit();
?>

<?php
/**
 * Admin Footer Template
 * Include this at the end of all admin pages
 * 
 * Usage: include 'includes/footer.php';
 */
?>

</div> <!-- End main-content -->
</body>
</html>

<header class="admin-header">
    <div class="header-content">
        <h3>Admin Panel</h3>
        <nav class="admin-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage_testimonials.php">Testimonials</a>
            <a href="manage_gallery.php">Gallery</a>
            <a href="manage_features.php">Features</a>
            <a href="settings_seo.php">SEO & Tracking</a>
            <a href="logout.php" class="logout-btn">Logout</a>

        </nav>
    </div>
</header>
